import boto3
from flask import Flask, jsonify, make_response, request
# from flask_lambda import FlaskLambda
import json


app = Flask(__name__)


@app.route('/')
def hello_world():  # put application's code here
    return 'Hello World!'


@app.route('/create')
def create_instance():
    response_dict = {'successCode': 200, 'successMessage': 'Success'}
    received_dict = request.json
    # {
    #     "action": "new",
    #     "userId": "545yui4y3489175",
    #     "instanceType": "t2.small",
    #     "volumeSize": 30
    # }

    try:
        sqs_client = boto3.client('sqs')
        message = {"key": "value"}
        response = sqs_client.send_message(
            QueueUrl="https://sqs.ca-central-1.amazonaws.com/855092731476/cloudverse-provision",
            MessageBody=json.dumps(received_dict)
        )
        print(response)

    except Exception as ex:
        response_dict = {'successCode': 400, 'successMessage': 'Failed'}
    return jsonify(response_dict)


@app.errorhandler(404)
def resource_not_found(e):
    return make_response(jsonify(error='Not found!'), 404)


if __name__ == '__main__':
    app.run()
